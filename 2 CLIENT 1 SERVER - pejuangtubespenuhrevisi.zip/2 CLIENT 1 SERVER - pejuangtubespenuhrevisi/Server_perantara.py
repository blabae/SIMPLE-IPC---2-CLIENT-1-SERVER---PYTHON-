#https://github.com/pejuangtubespenuhrevisi
#BELA SUKMAWATI
#TEKNIK INFORMATIKA 2015
#FAKULTAS INFORMATIKA 2015
#TELKOM UNIVERSITY 2015

import socket

lis1=socket.socket()
lis2=socket.socket()
alamatserver = "10.20.197.215"
portserver = 888

alamatserver2="10.20.197.215"
portserver2=999

lis1.bind((alamatserver,portserver))
lis2.bind((alamatserver2,portserver2))

lis1.listen(10)
lis2.listen(20)

while True:
    c1, addr1 =lis1.accept()
    c2, addr2 = lis2.accept()

    print("Client A telah terhubung : ", addr1)
    print("Client B telah terhubung : ", addr2)

    while True :
        pesanA = c1.recv(1024).decode()
        print("client A \t:", pesanA)
        c2.send(pesanA.encode())

        pesanB = c2.recv(1024).decode()
        print("client B \t:", pesanB)
        c1.send(pesanB.encode())
c1.close()
c2.close()