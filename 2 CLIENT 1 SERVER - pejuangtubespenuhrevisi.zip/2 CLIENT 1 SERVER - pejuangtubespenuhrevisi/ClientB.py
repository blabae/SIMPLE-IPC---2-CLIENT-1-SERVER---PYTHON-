#https://github.com/pejuangtubespenuhrevisi
#BELA SUKMAWATI
#TEKNIK INFORMATIKA 2015
#FAKULTAS INFORMATIKA 2015
#TELKOM UNIVERSITY 2015

import socket

lis = socket.socket()

ipserver = "192.168.1.108"
port = 888

lis.connect((ipserver, port))

while True:

    pesan_terima = lis.recv(1024).decode()
    print("Client A \t:", pesan_terima)

    pesan_kirim = input("Client B\t: ")
    lis.send(pesan_kirim.encode())

lis.close()
