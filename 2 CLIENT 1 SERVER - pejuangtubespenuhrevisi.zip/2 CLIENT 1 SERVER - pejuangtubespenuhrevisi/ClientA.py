#https://github.com/pejuangtubespenuhrevisi
#BELA SUKMAWATI
#TEKNIK INFORMATIKA 2015
#FAKULTAS INFORMATIKA 2015
#TELKOM UNIVERSITY 2015

import socket

lis = socket.socket()

ipserver = "10.20.197.215"
port = 888

lis.connect((ipserver,port))

while True:
    pesan_kirim = input("Client A\t: ")
    lis.send(pesan_kirim.encode())

    pesan_terima = lis.recv(1024).decode()
    print("Client B \t:",pesan_terima)

lis.close()
